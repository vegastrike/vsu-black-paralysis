import Assignment1Basics
import string


def findBlankLines(xs):
# finds the empty strings in the list, or in the case of
# a windows text file being parsed, the "\r" characters too
	index_list = []
	for index in range (len(xs)):
		if xs[index] == "":
			index_list.append(index)
	return index_list


def pairOff(xs,x):
# a list of adjacent elements of xs is returned, with the
# final pair being the last of xs, and x
	zipped_list = []
	for index in range (len(xs) - 1):
		zipped_list.append((xs[index],xs[index + 1]))
	zipped_list.append((xs[-1],x))
	return zipped_list


def between(a,b,xs):
# returns between but not including a and b in xs
	return xs[a + 1 : b]


def makeFields(list_indices,xs):
# returns a list of fields from xs, defined
# by the ranges given in list_indices
	fielded_list = []
	for index in range (len(list_indices)):
		if (list_indices[index])[1] - (list_indices[index])[0] > 1 :
			fielded_list.append(between((list_indices[index])[0],(list_indices[index])[1],xs))
	return fielded_list


def parseOtherFields(xss):
# returns the first element from xss, and the
# heads and tails of the subsequent elements in xss
	f_list = xss[0]
	s_list = []
	for index in range (1,len(xss)):
		s_list.append((xss[index][0],xss[index][1:]))
	return (f_list,s_list)


def parseInfoFile(cs):
# gives out a nice tuple of the info in cs, all formatted :-)
	doc_strs = string.split(cs,"\n")
	doc_blnk_id = findBlankLines(doc_strs)
	doc_blnk_rng = pairOff(doc_blnk_id,(len(doc_strs) - 1))
	doc_txt_sctns = makeFields(doc_blnk_rng,doc_strs)
	main_body = parseOtherFields(doc_txt_sctns)
	return (doc_strs[0],doc_strs[1],doc_strs[2],main_body[0],main_body[1])
			