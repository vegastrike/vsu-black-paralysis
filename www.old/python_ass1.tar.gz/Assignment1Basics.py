import string


def allTags():
	return [":NAME",":EMAIL",":URL",":BLURB",":PROJECTS"]


def makeProjectTitle(x):
	return "<li><i>" + x + "</i><p>"


def showFieldDefns(fds):
	(n,e,u,b,ps) = fds
	pros = []
	for index in range (len(ps)):
		pros.append(string.join([ps[index][0]] + ps[index][1],"\n"))
	return string.join((n,e,u,"",string.join(b,"\n"),string.join(pros,"\n")),"\n")
