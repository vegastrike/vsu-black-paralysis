#!/usr/bin/python

import Assignment1Basics
import ParseInfo
import BuildHtml
import sys


def main(f):
	in_file = open(f,"r")
	cs = in_file.read()
	in_file.close()
	fds = ParseInfo.parseInfoFile(cs)
	print Assignment1Basics.showFieldDefns(fds)
	in_file = open(frameFile(),"r")
	fr = in_file.read()
	in_file.close()
	out_file = open(htmlFilePath(f),"w")
	out_file.write(BuildHtml.buildHtmlFile(fr,fds))
	out_file.close()


def frameFile():
	return "frame.html"


def htmlFilePath(f):
	num = f.index(".")
	name = ""
	for index in range (num):
		name = name + f[index]
	return name + ".html"


filenames = sys.argv[1:]
for i in range (len(filenames)):
	print
	print "Formatting",
	print filenames[i]
	print
	main(filenames[i])
	print
	print "File formatting complete."
	print
