import Assignment1Basics
import string


def makeProject(p):
# makes a project into the appropriate format
	rest_text = ""
	for index in range (len(p[1])):
		rest_text = rest_text + p[1][index] + "\n"
	return Assignment1Basics.makeProjectTitle(p[0]) + "\n" + rest_text


def replaceWord(s,fds):
# if s is a tag, it is replaced with the appropriate
# data from fds, else it is left alone
	if s not in Assignment1Basics.allTags():
		return s
	elif Assignment1Basics.allTags().index(s) <= 2:
		return fds[Assignment1Basics.allTags().index(s)]
	elif Assignment1Basics.allTags().index(s) == 3:
		return string.join(fds[Assignment1Basics.allTags().index(s)],"\n")
	else:
		complete_string = ""
		for i in range (len(fds[4])):
			complete_string = complete_string + makeProject(fds[4][i])
		return complete_string


def buildHtmlFile(cs,fds):
# returns the contents of the html file built from cs and fds
	lines = string.split(cs,"\n")
	for i in range (len(lines)):
		words = string.split(lines[i]," ")
		for j in range (len(words)):
			words[j] = replaceWord(words[j],fds)
		lines[i] = string.join(words," ")
	return string.join(lines,"\n")
