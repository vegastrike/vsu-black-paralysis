/* PirxxLocator.h - Wrapper for XML location information
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: PirxxLocator.h,v 1.4 2003/02/28 10:18:09 jhermann Exp $
 */

#ifndef PIRXX_PIRXXLOCATOR_H
#define PIRXX_PIRXXLOCATOR_H

// Python
#include <Python.h>

// Xerces
#include <xercesc/util/PlatformUtils.hpp>

// PIRXX
#include "PirxxUtil.h"

class Locator;

// SAX2 locator
extern PyTypeObject PirxxSAX2Locator_Type;

struct PirxxSAX2Locator {
    PyObject_HEAD
    const Locator* locator;
};

#define PirxxSAX2Locator_Check(o) ((o)->ob_type == &PirxxSAX2Locator_Type)

extern PirxxObject PirxxSAX2Locator_New(const Locator*const locator);
extern void PirxxSAX2Locator_Invalidate(PirxxSAX2Locator* self);


// Exception locator
extern PyTypeObject PirxxExcLocator_Type;

struct PirxxExcLocator {
    PyObject_HEAD
    PyObject* pubid;
    PyObject* sysid;
    unsigned int line;
    unsigned int col;
};

#define PirxxExcLocator_Check(o) ((o)->ob_type == &PirxxExcLocator_Type)

extern PirxxObject PirxxExcLocator_New(const XMLCh* pubid, const XMLCh* sysid, unsigned int line, unsigned int col);


// init
extern void PirxxLocator_Init();


#endif
