/* PirxxLocator.cpp - Wrapper for XML location information
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: PirxxLocator.cpp,v 1.7 2003/02/28 10:18:09 jhermann Exp $
 */

#include "PirxxLocator.h"

// C Runtime

// Python
#include <Python.h>

// Xerces
#include <xercesc/sax/Locator.hpp>

// PIRXX
#include "PirxxUtil.h"


//////////////////////////////////////////////////////////////////////////////
// PirxxSAX2Locator
//////////////////////////////////////////////////////////////////////////////

staticforward PyMethodDef PirxxSAX2Locator_Methods[];


static void PirxxSAX2Locator_Free(PirxxSAX2Locator* self)
{
    PyMem_DEL(self);
}

static bool PirxxSAX2Locator_IsValid(PirxxSAX2Locator* self)
{
    bool ok = self && self->locator;

    if (!ok) {
        PirxxSetErrorObject(PirxxBuildSAXException(
            "SAXNotSupportedException", "Locator access after parse"
        ));
    }

    return ok;
}


static int PirxxSAX2Locator_Print(PirxxSAX2Locator* self, FILE* fp, int flags)
{
    if (!self) return -1;

    fprintf(fp, "<pirxx._pirxx.PirxxSAX2Locator object at %p>", self);

    return 0;
}


static PyObject* PirxxSAX2Locator_GetAttr(PirxxSAX2Locator* self, char* name)
{
    return Py_FindMethod(PirxxSAX2Locator_Methods, (PyObject*) self, name);
}


static char PirxxSAX2Locator_Type__doc__[] = 
    "Xerces Locator Object.\n"
    ;

PyTypeObject PirxxSAX2Locator_Type = {
    PyObject_HEAD_INIT(0)                // init at startup!
    0,                                   // ob_size
    "pirxx._pirxx.PirxxSAX2Locator",     // tp_name
    sizeof(PirxxSAX2Locator),            // tp_basicsize
    0,                                   // tp_itemsize
    //  slots 
    (destructor) PirxxSAX2Locator_Free,  // tp_dealloc
    (printfunc) PirxxSAX2Locator_Print,  // tp_print
    (getattrfunc) PirxxSAX2Locator_GetAttr, // tp_getattr
    (setattrfunc) 0,                     // tp_setattr
    (cmpfunc) 0,                         // tp_compare
    (reprfunc) 0,                        // tp_repr
    0,                                   // tp_as_number
    0,                                   // tp_as_sequence
    0,                                   // tp_as_mapping
    (hashfunc) 0,                        // tp_hash
    (ternaryfunc) 0,                     // tp_call
    (reprfunc) 0,                        // tp_str
    (getattrofunc) 0,                    // tp_getattro
    (setattrofunc) 0,                    // tp_setattro
    0,                                   // tp_as_buffer
    0,                                   // tp_xxx4
    PirxxSAX2Locator_Type__doc__         // tp_doc
};


static char PirxxSAX2Locator_getColumnNumber_doc[] =
    "Return the column number where the current event ends.";

static PyObject* PirxxSAX2Locator_getColumnNumber(PirxxSAX2Locator* self, PyObject* args)
{
    if (!PyArg_NoArgs(args) || !PirxxSAX2Locator_IsValid(self)) return 0;
    return PyInt_FromLong(self->locator->getColumnNumber());
}

static char PirxxSAX2Locator_getLineNumber_doc[] =
    "Return the line number where the current event ends.";

static PyObject* PirxxSAX2Locator_getLineNumber(PirxxSAX2Locator* self, PyObject* args)
{
    if (!PyArg_NoArgs(args) || !PirxxSAX2Locator_IsValid(self)) return 0;
    return PyInt_FromLong(self->locator->getLineNumber());
}


static char PirxxSAX2Locator_getPublicId_doc[] =
    "Return the public identifier for the current event.";

static PyObject* PirxxSAX2Locator_getPublicId(PirxxSAX2Locator* self, PyObject* args)
{
    if (!PyArg_NoArgs(args) || !PirxxSAX2Locator_IsValid(self)) return 0;

    // Return "None" for empty strings
    const XMLCh* pubid = self->locator->getPublicId();
    if (!pubid || !*pubid) {
        Py_INCREF(Py_None);
        return Py_None;
    }
    
    return PirxxBuildUnicode(pubid).incref();
}


static char PirxxSAX2Locator_getSystemId_doc[] =
    "Return the system identifier for the current event.";

static PyObject* PirxxSAX2Locator_getSystemId(PirxxSAX2Locator* self, PyObject* args)
{
    if (!PyArg_NoArgs(args) || !PirxxSAX2Locator_IsValid(self)) return 0;

    // Return "None" for empty strings
    const XMLCh* sysid = self->locator->getSystemId();
    if (!sysid || !*sysid) {
        Py_INCREF(Py_None);
        return Py_None;
    }
    
    return PirxxBuildUnicode(self->locator->getSystemId()).incref();
}


statichere PyMethodDef PirxxSAX2Locator_Methods[] =
{
    PIRXX_METHOD(PirxxSAX2Locator, getColumnNumber),
    PIRXX_METHOD(PirxxSAX2Locator, getLineNumber),
    PIRXX_METHOD(PirxxSAX2Locator, getPublicId),
    PIRXX_METHOD(PirxxSAX2Locator, getSystemId),

    {0, 0} // end of list
};


PirxxObject PirxxSAX2Locator_New(const Locator*const locator)
{
    PirxxSAX2Locator* self = PyObject_NEW(PirxxSAX2Locator, &PirxxSAX2Locator_Type);

    if (self) {
        self->locator = locator;
    }

    return PirxxObject((PyObject*) self, true);
}


void PirxxSAX2Locator_Invalidate(PirxxSAX2Locator* self)
{
    if (self) {
        self->locator = 0;
    }
}


//////////////////////////////////////////////////////////////////////////////
// PirxxExcLocator
//////////////////////////////////////////////////////////////////////////////

staticforward PyMethodDef PirxxExcLocator_Methods[];


static void PirxxExcLocator_Free(PirxxExcLocator* self)
{
    Py_DECREF(self->pubid);
    Py_DECREF(self->sysid);

    PyMem_DEL(self);
}


static int PirxxExcLocator_Print(PirxxExcLocator* self, FILE* fp, int flags)
{
    if (!self) return -1;

    fprintf(fp, "<pirxx._pirxx.PirxxExcLocator object at %p>", self);

    return 0;
}


static PyObject* PirxxExcLocator_GetAttr(PirxxExcLocator* self, char* name)
{
    return Py_FindMethod(PirxxExcLocator_Methods, (PyObject*) self, name);
}


static char PirxxExcLocator_Type__doc__[] = 
    "Xerces Locator Object.\n"
    ;

PyTypeObject PirxxExcLocator_Type = {
    PyObject_HEAD_INIT(0)                // init at startup!
    0,                                   // ob_size
    "pirxx._pirxx.PirxxExcLocator",      // tp_name
    sizeof(PirxxExcLocator),             // tp_basicsize
    0,                                   // tp_itemsize
    //  slots 
    (destructor) PirxxExcLocator_Free,   // tp_dealloc
    (printfunc) PirxxExcLocator_Print,   // tp_print
    (getattrfunc) PirxxExcLocator_GetAttr, // tp_getattr
    (setattrfunc) 0,                     // tp_setattr
    (cmpfunc) 0,                         // tp_compare
    (reprfunc) 0,                        // tp_repr
    0,                                   // tp_as_number
    0,                                   // tp_as_sequence
    0,                                   // tp_as_mapping
    (hashfunc) 0,                        // tp_hash
    (ternaryfunc) 0,                     // tp_call
    (reprfunc) 0,                        // tp_str
    (getattrofunc) 0,                    // tp_getattro
    (setattrofunc) 0,                    // tp_setattro
    0,                                   // tp_as_buffer
    0,                                   // tp_xxx4
    PirxxExcLocator_Type__doc__          // tp_doc
};


static char PirxxExcLocator_getColumnNumber_doc[] =
    "Return the column number where the current event ends.";

static PyObject* PirxxExcLocator_getColumnNumber(PirxxExcLocator* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    return PyInt_FromLong(self->col);
}

static char PirxxExcLocator_getLineNumber_doc[] =
    "Return the line number where the current event ends.";

static PyObject* PirxxExcLocator_getLineNumber(PirxxExcLocator* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    return PyInt_FromLong(self->line);
}


static char PirxxExcLocator_getPublicId_doc[] =
    "Return the public identifier for the current event.";

static PyObject* PirxxExcLocator_getPublicId(PirxxExcLocator* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    Py_INCREF(self->pubid);
    return self->pubid;
}


static char PirxxExcLocator_getSystemId_doc[] =
    "Return the system identifier for the current event.";

static PyObject* PirxxExcLocator_getSystemId(PirxxExcLocator* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    Py_INCREF(self->sysid);
    return self->sysid;
}


statichere PyMethodDef PirxxExcLocator_Methods[] =
{
    PIRXX_METHOD(PirxxExcLocator, getColumnNumber),
    PIRXX_METHOD(PirxxExcLocator, getLineNumber),
    PIRXX_METHOD(PirxxExcLocator, getPublicId),
    PIRXX_METHOD(PirxxExcLocator, getSystemId),

    {0, 0} // end of list
};


PirxxObject PirxxExcLocator_New(const XMLCh* pubid, const XMLCh* sysid, unsigned int line, unsigned int col)
{
    PirxxExcLocator* self = PyObject_NEW(PirxxExcLocator, &PirxxExcLocator_Type);

    if (self) {
        if (!pubid || !*pubid) {
            Py_INCREF(Py_None);
            self->pubid = Py_None;
        } else {
            self->pubid = PirxxBuildUnicode(pubid).incref();
        }
        if (!sysid || !*sysid) {
            Py_INCREF(Py_None);
            self->sysid = Py_None;
        } else {
            self->sysid = PirxxBuildUnicode(sysid).incref();
        }
        self->line = line;
        self->col = col;
    }

    return PirxxObject((PyObject*) self, true);
}


//////////////////////////////////////////////////////////////////////////////
// Init
//////////////////////////////////////////////////////////////////////////////

void PirxxLocator_Init()
{
    // Patch type objects
    PirxxSAX2Locator_Type.ob_type = &PyType_Type;
    PirxxExcLocator_Type.ob_type = &PyType_Type;
}
