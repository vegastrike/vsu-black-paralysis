/* PyHandler.cpp - Bridge between Xerces and Python handler classes
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: PyHandler.cpp,v 1.26 2003/02/28 10:18:09 jhermann Exp $
 */

#include "PyHandler.h"

// Python
#include <Python.h>

// Xerces
#include <xercesc/sax/SAXParseException.hpp>
#include <xercesc/sax2/Attributes.hpp>

// PIRXX
#include "PirxxUtil.h"
#include "PirxxLocator.h"
#include "PyInputSource.h"


/////////////////////////////////////////////////////////////////////////////
/// PirxxHandler
/////////////////////////////////////////////////////////////////////////////

PirxxHandler::PirxxHandler(PyObject* handler)
    : m_handler(handler)
{
}


PirxxHandler::~PirxxHandler()
{
}


// takes ownership of args!
PirxxObject PirxxHandler::operator()(const char* method, PyObject* args)
{
    PirxxObject auto_args(args, true);

    // Use assignment instead of a ctor, so that we can do our own null ptr handling
    PirxxObject func;
    func = PyObject_GetAttrString(m_handler, const_cast<char*>(method));
    if (!func) {
        PyErr_SetString(PyExc_AttributeError, const_cast<char*>(method));
        throw PythonExceptionCarrier();
    }
    func.decref(); // give up new ref that getattr returned
    if (!PyCallable_Check(func)) {
        PyErr_Format(PyExc_TypeError, "Invalid non-callable attribute '%s'", method);
        throw PythonExceptionCarrier();
    }

    //PIRXX_DEBUG("\n*** Calling " << method << "() with " << PyString_AS_STRING(PyObject_Repr(args)));

    return PirxxObject(PyObject_CallObject(func, auto_args), true);
}


/////////////////////////////////////////////////////////////////////////////
/// PyContentHandler
/////////////////////////////////////////////////////////////////////////////

PyContentHandler::PyContentHandler(PyObject* handler, bool namespaces)
    : m_namespaces(namespaces)
    , m_handler(handler)
    , m_locator()
    , m_attr_class(PirxxGetObject("xml.sax.xmlreader",
        m_namespaces ? "AttributesNSImpl" : "AttributesImpl"))
    , m_attr_empty()
{
    PirxxObject two_0_dicts(Py_BuildValue(const_cast<char*>(m_namespaces ? "({}{})" : "({})")), true);
    PirxxObject attr_empty(PyObject_CallObject(m_attr_class, two_0_dicts), true);
    m_attr_empty = attr_empty;
}


PyContentHandler::~PyContentHandler()
{
    if (m_locator) {
        PirxxSAX2Locator_Invalidate((PirxxSAX2Locator*)m_locator.ptr());
    }
}


PirxxObject PyContentHandler::build_attrs(const Attributes& attrs)
{
    // Optimization for empty attribute lists (return pre-built one)
    if (attrs.getLength() == 0) {
        return m_attr_empty;
    }

    // Build attribute instance
    if (m_namespaces) {
        PirxxObject pyattr(PyDict_New(), true);
        PirxxObject qnames(PyDict_New(), true);

        for (unsigned int idx = 0; idx < attrs.getLength(); ++idx) {
            const XMLCh* xmlch_uri = attrs.getURI(idx);

            PirxxObject uri = PirxxBuildNoneOrStringOrUnicode(xmlch_uri);
            PirxxObject lname = PirxxBuildStringOrUnicode(attrs.getLocalName(idx));
            PirxxObject uriname(Py_BuildValue("(OO)", uri.ptr(), lname.ptr()), true);
            PirxxObject qname = PirxxBuildStringOrUnicode(attrs.getQName(idx));
            PirxxObject value = PirxxBuildStringOrUnicode(attrs.getValue(idx));

            // attrs should be of the form {(ns_uri, lname): value, ...},
            PyDict_SetItem(pyattr, uriname, value);

            // qnames of the form {(ns_uri, lname): qname, ...}
            PyDict_SetItem(qnames, uriname, qname);
        }

        //PIRXX_DEBUG("*** Attrs = " << PyString_AS_STRING(PyObject_Repr(pyattr)));
        //PIRXX_DEBUG("*** Qnames = " << PyString_AS_STRING(PyObject_Repr(qnames)));

        PirxxObject args(Py_BuildValue("(OO)", pyattr.ptr(), qnames.ptr()), true);
        PirxxObject result(PyObject_CallObject(m_attr_class, args), true);
        return result;
    } else {
        PirxxObject pyattr(PyDict_New(), true);

        for (unsigned int idx = 0; idx < attrs.getLength(); ++idx) {
            // attrs should be of the form {name : value}
            PirxxObject name = PirxxBuildStringOrUnicode(attrs.getQName(idx));
            PirxxObject value = PirxxBuildStringOrUnicode(attrs.getValue(idx));
            PyDict_SetItem(pyattr, name, value);
        }

        PirxxObject args(Py_BuildValue("(O)", pyattr.ptr()), true);
        PirxxObject result(PyObject_CallObject(m_attr_class, args), true);
        return result;
    }
}


void PyContentHandler::setDocumentLocator(const Locator*const locator)
{
    m_locator = PirxxSAX2Locator_New(locator);
    m_handler("setDocumentLocator", Py_BuildValue("(O)", m_locator.ptr()));
}


void PyContentHandler::startDocument()
{
    m_handler("startDocument");
}


void PyContentHandler::endDocument()
{
    m_handler("endDocument");
    if (m_locator) {
        PirxxSAX2Locator_Invalidate((PirxxSAX2Locator*)m_locator.ptr());
    }
}


void PyContentHandler::startPrefixMapping(const XMLCh*const prefix, const XMLCh*const uri)
{
    PirxxObject pyprefix = PirxxBuildStringOrUnicode(prefix);
    PirxxObject pyuri = PirxxBuildNoneOrStringOrUnicode(uri);
    m_handler("startPrefixMapping", Py_BuildValue("(OO)", pyprefix.ptr(), pyuri.ptr()));
}


void PyContentHandler::endPrefixMapping(const XMLCh*const prefix)
{
    PirxxObject pyprefix = PirxxBuildStringOrUnicode(prefix);
    m_handler("endPrefixMapping", Py_BuildValue("(O)", pyprefix.ptr()));
}


void PyContentHandler::startElement(const XMLCh*const uri, const XMLCh*const localname, const XMLCh*const qname, const Attributes& attrs)
{
    //PIRXX_DEBUG("*** start: uri=" << *uri << "; local=" << *localname);
    if (m_namespaces) {
        PirxxObject pyuri = PirxxBuildNoneOrStringOrUnicode(uri);
        PirxxObject pylocalname = PirxxBuildStringOrUnicode(localname);
        PirxxObject pyqname = PirxxBuildStringOrUnicode(qname);
        m_handler("startElementNS", Py_BuildValue("((OO)OO)",
            pyuri.ptr(), pylocalname.ptr(), pyqname.ptr(), build_attrs(attrs).ptr()));
    } else {
        PirxxObject pyqname = PirxxBuildStringOrUnicode(qname);
        m_handler("startElement", Py_BuildValue("(OO)", pyqname.ptr(), build_attrs(attrs).ptr()));
    }
}


void PyContentHandler::endElement(const XMLCh*const uri, const XMLCh*const localname, const XMLCh*const qname)
{
    if (m_namespaces) {
        PirxxObject pyuri = PirxxBuildNoneOrStringOrUnicode(uri);
        PirxxObject pylocalname = PirxxBuildStringOrUnicode(localname);
        PirxxObject pyqname = PirxxBuildStringOrUnicode(qname);
        m_handler("endElementNS", Py_BuildValue("((OO)O)",
            pyuri.ptr(), pylocalname.ptr(), pyqname.ptr()));
    } else {
        PirxxObject pyqname = PirxxBuildStringOrUnicode(qname);
        m_handler("endElement", Py_BuildValue("(O)", pyqname.ptr()));
    }
}


void PyContentHandler::characters(const XMLCh*const chars, const unsigned int length)
{
    m_handler("characters", Py_BuildValue("(u#)", chars, length));
}


void PyContentHandler::ignorableWhitespace(const XMLCh*const chars, const unsigned int length)
{
    m_handler("ignorableWhitespace", Py_BuildValue("(u#)", chars, length));
}


void PyContentHandler::processingInstruction(const XMLCh*const target, const XMLCh*const data)
{
    PirxxObject pytarget = PirxxBuildStringOrUnicode(target);
    PirxxObject pydata = PirxxBuildStringOrUnicode(data);
    m_handler("processingInstruction", Py_BuildValue("(OO)", pytarget.ptr(), pydata.ptr()));
}


void PyContentHandler::skippedEntity(const XMLCh*const name)
{
    PirxxObject pyname = PirxxBuildStringOrUnicode(name);
    m_handler("skippedEntity", Py_BuildValue("(O)", pyname.ptr()));
}


/////////////////////////////////////////////////////////////////////////////
/// PyErrorHandler
/////////////////////////////////////////////////////////////////////////////

PyErrorHandler::PyErrorHandler(PyObject* handler)
    : m_handler(handler)
{
}


PyErrorHandler::~PyErrorHandler()
{
}


void PyErrorHandler::handleError(const char* method, const SAXParseException& exception)
{
    if (m_handler != Py_None) {
        // call handler method
        PirxxObject saxexc = PirxxBuildSAXParseException(exception);
        PirxxObject result = PyObject_CallMethod(m_handler, const_cast<char*>(method), "(N)", saxexc.ptr());
    } else {
        throw exception;
    }
}


void PyErrorHandler::warning(const SAXParseException& exception)
{
    handleError("warning", exception);
}


void PyErrorHandler::error(const SAXParseException& exception)
{
    handleError("error", exception);
}


void PyErrorHandler::fatalError(const SAXParseException& exception)
{
    handleError("fatalError", exception);
}


void PyErrorHandler::resetErrors()
{
    // do nothing
}


/////////////////////////////////////////////////////////////////////////////
/// PyDTDHandler
/////////////////////////////////////////////////////////////////////////////

PyDTDHandler::PyDTDHandler(PyObject* handler)
    : m_handler(handler)
{
}


PyDTDHandler::~PyDTDHandler()
{
}


void PyDTDHandler::notationDecl(const XMLCh*const name,
        const XMLCh*const publicId, const XMLCh*const systemId)
{
    PirxxObject pyname = PirxxBuildStringOrUnicode(name);
    PirxxObject pypublicId = PirxxBuildNoneOrStringOrUnicode(publicId);
    PirxxObject pysystemId = PirxxBuildNoneOrStringOrUnicode(systemId);
    m_handler("notationDecl", Py_BuildValue("(OOO)", pyname.ptr(),
        pypublicId.ptr(), pysystemId.ptr()));
}


void PyDTDHandler::unparsedEntityDecl(const XMLCh*const name,
        const XMLCh*const publicId, const XMLCh*const systemId,
        const XMLCh*const notationName)
{
    PirxxObject pyname = PirxxBuildStringOrUnicode(name);
    PirxxObject pypublicId = PirxxBuildNoneOrStringOrUnicode(publicId);
    PirxxObject pysystemId = PirxxBuildNoneOrStringOrUnicode(systemId);
    PirxxObject pynotationName = PirxxBuildNoneOrStringOrUnicode(notationName);
    m_handler("unparsedEntityDecl", Py_BuildValue("(OOOO)", pyname.ptr(),
        pypublicId.ptr(), pysystemId.ptr(), pynotationName.ptr()));
}


void PyDTDHandler::resetDocType()
{
    // we do not support reuse
}


/////////////////////////////////////////////////////////////////////////////
/// PyEntityResolver
/////////////////////////////////////////////////////////////////////////////

PyEntityResolver::PyEntityResolver(PyObject* handler)
    : m_handler(handler)
{
}


PyEntityResolver::~PyEntityResolver()
{
}


InputSource* PyEntityResolver::resolveEntity(const XMLCh*const publicId, const XMLCh*const systemId)
{
    PirxxObject pypublicId = PirxxBuildStringOrUnicode(publicId);
    PirxxObject pysystemId = PirxxBuildStringOrUnicode(systemId);
    PirxxObject entity = m_handler("resolveEntity", Py_BuildValue("(OO)", 
        pypublicId.ptr(), pysystemId.ptr()));

    if (PyString_Check(entity)) {
        char* sysid = XMLString::transcode(systemId);
        if (strcmp(sysid, PyString_AS_STRING(entity.ptr())) == 0) {
            // resolver returned original system id, let Xerces handle that internally
            delete[] sysid;
            return 0;
        }
        delete[] sysid;
    } else if (PyUnicode_Check(entity)) {
        if (XMLString::compareString(systemId, PyUnicode_AS_UNICODE(entity.ptr())) == 0) {
            // resolver returned original system id, let Xerces handle that internally
            return 0;
        }
    }

    // create an input source from the returned entity value
    PyObject* source = PirxxCallObject("xml.sax.saxutils", "prepare_input_source",
        Py_BuildValue("(O)", entity.ptr()));
    if (!source) throw PythonExceptionCarrier();
    return new PyInputSource(source);
}


/////////////////////////////////////////////////////////////////////////////
/// PyLexicalHandler
/////////////////////////////////////////////////////////////////////////////

PyLexicalHandler::PyLexicalHandler(PyObject* handler)
    : m_handler(handler)
{
}


PyLexicalHandler::~PyLexicalHandler()
{
}


void PyLexicalHandler::comment(const XMLCh*const chars, const unsigned int length)
{
    m_handler("comment", Py_BuildValue("(N)", PyUnicode_FromUnicode(chars, length)));
}


void PyLexicalHandler::startDTD(const XMLCh*const name, const XMLCh*const publicId, const XMLCh*const systemId)
{
    PirxxObject pyname = PirxxBuildStringOrUnicode(name);
    PirxxObject pubid = PirxxBuildNoneOrStringOrUnicode(publicId);
    PirxxObject sysid = PirxxBuildNoneOrStringOrUnicode(systemId);
    m_handler("startDTD", Py_BuildValue("(OOO)", pyname.ptr(), pubid.ptr(), sysid.ptr()));
}


void PyLexicalHandler::endDTD()
{
    m_handler("endDTD");
}


/*
    The start and end of the document entity is not reported. The
    start and end of the external DTD subset is reported with the
    pseudo-name '[dtd]'.

    Skipped entities will be reported through the skippedEntity
    event of the ContentHandler rather than through this event.

    name is the name of the entity. If it is a parameter entity,
    the name will begin with '%'.
*/
void PyLexicalHandler::startEntity(const XMLCh*const name)
{
    PirxxObject pyname = PirxxBuildStringOrUnicode(name);
    m_handler("startEntity", Py_BuildValue("(O)", pyname.ptr()));
}


void PyLexicalHandler::endEntity(const XMLCh*const name)
{
    PirxxObject pyname = PirxxBuildStringOrUnicode(name);
    m_handler("endEntity", Py_BuildValue("(O)", pyname.ptr()));
}


void PyLexicalHandler::startCDATA()
{
    m_handler("startCDATA");
}


void PyLexicalHandler::endCDATA()
{
    m_handler("endCDATA");
}

