/* PyXMLReader.h - Extension type wrapping Xerces SAX2XMLReader
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: PyXMLReader.h,v 1.5 2001/11/14 07:00:59 jhermann Exp $
 */

#ifndef PIRXX_XMLREADER_H
#define PIRXX_XMLREADER_H

// Python
#include <Python.h>

// PIRXX
#include "PirxxUtil.h"

// forwards
class SAX2XMLReader;
class PyIncrementalParser;

extern PyTypeObject PyXMLReader_Type;

struct PyXMLReader {
    PyObject_HEAD
    SAX2XMLReader* parser;
    PyIncrementalParser* incparser;
    struct cpp_members {
        PirxxObject cont_handler;
        PirxxObject dtd_handler;
        PirxxObject ent_handler;
        PirxxObject err_handler;
        PirxxObject lex_handler;
    }* m_;
};

#define PyXMLReader_Check(o) ((o)->ob_type == &PyXMLReader_Type)


extern PirxxObject PyXMLReader_New();
extern void PyXMLReader_Init();

#endif
