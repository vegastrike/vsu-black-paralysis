/* PyHandler.h - Bridge between Xerces and Python handler classes
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: PyHandler.h,v 1.12 2003/02/28 10:18:09 jhermann Exp $
 */

#ifndef PIRXX_PYHANDLER_H
#define PIRXX_PYHANDLER_H

// Python
#include <Python.h>

// Xerces
#include <xercesc/sax2/ContentHandler.hpp>
#include <xercesc/sax2/LexicalHandler.hpp>
#include <xercesc/sax/ErrorHandler.hpp>
#include <xercesc/sax/DTDHandler.hpp>
#include <xercesc/sax/EntityResolver.hpp>

// PIRXX
#include "PirxxUtil.h"


class PirxxHandler {
public:
    PirxxHandler(PyObject* handler);
    virtual ~PirxxHandler();

    virtual PirxxObject operator()(const char* method, PyObject* args = 0);

private:
    // overload unwanted compiler defaults
    PirxxHandler(const PirxxHandler&);
    PirxxHandler& operator=(const PirxxHandler&);

    PirxxObject m_handler;
};


class PyContentHandler : public ContentHandler {
public:
    PyContentHandler(PyObject* handler, bool namespaces);
    virtual ~PyContentHandler();

    virtual void setDocumentLocator(const Locator*const locator);

    virtual void startDocument();
    virtual void endDocument();

    virtual void startPrefixMapping(const XMLCh*const prefix, const XMLCh*const uri);
    virtual void endPrefixMapping(const XMLCh*const prefix);

    virtual void startElement(const XMLCh*const uri, const XMLCh*const localname, const XMLCh*const qname, const Attributes& attrs);
    virtual void endElement(const XMLCh*const uri, const XMLCh*const localname, const XMLCh*const qname);

    virtual void characters(const XMLCh*const chars, const unsigned int length);
    virtual void ignorableWhitespace(const XMLCh*const chars, const unsigned int length);

    virtual void processingInstruction(const XMLCh*const target, const XMLCh*const data);
    virtual void skippedEntity(const XMLCh*const name);

private:
    // overload unwanted compiler defaults
    PyContentHandler(const PyContentHandler&);
    PyContentHandler& operator=(const PyContentHandler&);

    PirxxObject build_attrs(const Attributes& attrs);

    bool m_namespaces;
    PirxxHandler m_handler;
    PirxxObject m_locator;
    PirxxObject m_attr_class;
    PirxxObject m_attr_empty;
};


class PyErrorHandler : public ErrorHandler {
public:
    PyErrorHandler(PyObject* handler);
    virtual ~PyErrorHandler();

    virtual void warning(const SAXParseException& exception);
    virtual void error(const SAXParseException& exception);
    virtual void fatalError(const SAXParseException& exception);
    virtual void resetErrors();

private:
    // overload unwanted compiler defaults
    PyErrorHandler(const PyErrorHandler&);
    PyErrorHandler& operator=(const PyErrorHandler&);

    void handleError(const char* method, const SAXParseException& exception);

    PirxxObject m_handler;
};


class PyDTDHandler : public DTDHandler {
public:
    PyDTDHandler(PyObject* handler);
    virtual ~PyDTDHandler();

    /// Receive notification of a notation declaration event.
    virtual void notationDecl(const XMLCh*const name, const XMLCh*const publicId, const XMLCh*const systemId);

    /// Receive notification of an unparsed entity declaration event.
    virtual void unparsedEntityDecl(const XMLCh*const name, const XMLCh*const publicId, const XMLCh*const systemId, const XMLCh*const notationName);

    /// Reset the DocType object on its reuse.
    virtual void resetDocType();

private:
    // overload unwanted compiler defaults
    PyDTDHandler(const PyDTDHandler&);
    PyDTDHandler& operator=(const PyDTDHandler&);

    PirxxHandler m_handler;
};


class PyEntityResolver : public EntityResolver {
public:
    PyEntityResolver(PyObject* handler);
    virtual ~PyEntityResolver();
 
    /// Allow the application to resolve external entities.
    virtual InputSource* resolveEntity(const XMLCh*const publicId, const XMLCh*const systemId);

private:
    // overload unwanted compiler defaults
    PyEntityResolver(const PyEntityResolver&);
    PyEntityResolver& operator=(const PyEntityResolver&);

    PirxxHandler m_handler;
};


class PyLexicalHandler : public LexicalHandler {
public:
    PyLexicalHandler(PyObject* handler);
    virtual ~PyLexicalHandler();
 
    /// Receive notification of comments.
    virtual void comment(const XMLCh*const chars, const unsigned int length);

    /// Receive notification of the start of the DTD declarations.
    virtual void startDTD(const XMLCh*const name, const XMLCh*const publicId, const XMLCh*const systemId);

    /// Receive notification of the end of the DTD declarations.
    virtual void endDTD();

    /// Receive notification of the start of an entity.
    virtual void startEntity(const XMLCh*const name);

    /// Receive notification of the end of an entity.
    virtual void endEntity(const XMLCh*const name);

    /// Receive notification of the start of a CDATA section.
    virtual void startCDATA();

    /// Receive notification of the end of a CDATA section.
    virtual void endCDATA();

private:
    // overload unwanted compiler defaults
    PyLexicalHandler(const PyLexicalHandler&);
    PyLexicalHandler& operator=(const PyLexicalHandler&);

    PirxxHandler m_handler;
};


#endif
