/* PyInputSource.h - Bridge between Xerces and Python input sources
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id$
 */

#ifndef PIRXX_PYINPUTSOURCE_H
#define PIRXX_PYINPUTSOURCE_H

// Xerces
#include <sax/InputSource.hpp>


class PyInputSource : public InputSource {
public:
    PyInputSource(PyObject* source);
    virtual ~PyInputSource();


private:
    // overload unwanted compiler defaults
    PyInputSource(const PyInputSource&);
    PyInputSource& operator=(const PyInputSource&);

    PyObject* m_source;
};


#endif