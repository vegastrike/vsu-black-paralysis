/* PyXMLReader.cpp - Extension type wrapping Xerces SAX2XMLReader
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: PyXMLReader.cpp,v 1.17 2003/02/28 10:18:09 jhermann Exp $
 */

#include "PyXMLReader.h"

// C Runtime

// Python
#include <Python.h>

// Xerces
#include <xercesc/parsers/SAXParser.hpp>
#include <xercesc/sax/Locator.hpp>
#include <xercesc/sax/SAXParseException.hpp>
#include <xercesc/sax2/SAX2XMLReader.hpp>
#include <xercesc/sax2/XMLReaderFactory.hpp>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/util/XMLUni.hpp>

// PIRXX
#include "PirxxUtil.h"
#include "PyInputSource.h"
#include "PyHandler.h"


/////////////////////////////////////////////////////////////////////////////
/// Prototypes & Helpers
/////////////////////////////////////////////////////////////////////////////

static void PyXMLReader_Free(PyXMLReader* self);
staticforward PyMethodDef PyXMLReader_Methods[];


static PyObject* PyXMLReader_set_handler_slot(PirxxObject& slot, PyObject* args)
{
    // Check arguments
    PyObject* handler = 0;
    if (!PyArg_ParseTuple(args, "O", &handler)) return 0;

    // Replace handler
    slot = handler;

    // Return None
    Py_INCREF(Py_None);
    return Py_None;
}


struct parser_state {
    parser_state(PyXMLReader* self);
    
    SAX2XMLReader& parser;
    PyContentHandler cont_handler;
    PyErrorHandler err_handler;
    PyDTDHandler dtd_handler;
    PyEntityResolver ent_handler;
    PyLexicalHandler lex_handler;
};


parser_state::parser_state(PyXMLReader* self)
    : parser(*self->parser) // define alias for parser
    , cont_handler(self->m_->cont_handler,
        parser.getFeature(XMLUni::fgSAX2CoreNameSpaces))
    , err_handler(self->m_->err_handler)
    , dtd_handler(self->m_->dtd_handler)
    , ent_handler(self->m_->ent_handler)
    , lex_handler(self->m_->lex_handler)
{
    // set handlers (wrapping the stored Python handlers)
    parser.setContentHandler(&cont_handler);
    parser.setErrorHandler(&err_handler);
    parser.setDTDHandler(&dtd_handler);
    parser.setEntityResolver(&ent_handler);
    if (self->m_->lex_handler != Py_None) {
        parser.setLexicalHandler(&lex_handler);
    }
}


/////////////////////////////////////////////////////////////////////////////
/// Xerces XMLReader Interface
/////////////////////////////////////////////////////////////////////////////

static int PyXMLReader_Print(PyXMLReader* self, FILE* fp, int flags)
{
    if (!self) return -1;

    fprintf(fp, "<pirxx._pirxx.PyXMLReader object at %p>", self);

    return 0;
}


static PyObject* PyXMLReader_GetAttr(PyXMLReader* self, char* name)
{
    return Py_FindMethod(PyXMLReader_Methods, (PyObject*) self, name);
}


static int PyXMLReader_SetAttr(PyXMLReader* self, char* name, PyObject* value)
{
    PyErr_Format(PyExc_AttributeError, "Attribute '%s' unknown or read-only", name);
    return -1;
}


static char PyXMLReader_parse_doc[] = 
    "parse(input_source)\n"
    "Parse an XML document from a system identifier or an InputSource."
    ;

static PyObject* PyXMLReader_parse(PyXMLReader* self, PyObject* args)
{
    try {
        // Check arguments
        Py_INCREF(args);
        PirxxObject py_source = PirxxCallObject("xml.sax.saxutils", "prepare_input_source", args);

        // parse the source
        PyInputSource wrapped_source(py_source);
        parser_state state(self);
        state.parser.parse(wrapped_source);

        // return None
        Py_INCREF(Py_None);
        return Py_None;
    }
    catch (PythonExceptionCarrier& e) {
        e.restore();
    }
    catch (const SAXParseException& e) {
        PirxxSetErrorObject(PirxxBuildSAXParseException(e));
    }
    catch (const SAXException& e) {
        PirxxSetErrorObject(PirxxBuildSAXException(0, e.getMessage()));
    }
    catch (const XMLException& e) {
        PyErr_Format(PyExc_RuntimeError, "XMLException: %s:%d: %s",
            e.getSrcFile(), e.getSrcLine(), PirxxTranscode(e.getMessage()).c_str());
    }
    catch (const PirxxException& e) {
        PyErr_Format(PyExc_RuntimeError, "General exception in " __FILE__ ":%d: %s", 
            __LINE__, e.what());
    }
    catch (...) {
        PyErr_Format(PyExc_RuntimeError, "Unexpected C++ exception caught in " __FILE__ ":%d", __LINE__);
    }

    return 0; // indicate error
}


static char PyXMLReader_getContentHandler_doc[] = 
    "getContentHandler()\n"
    "Returns the current ContentHandler."
    ;

static PyObject* PyXMLReader_getContentHandler(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    return self->m_->cont_handler.incref();
}


static char PyXMLReader_setContentHandler_doc[] = 
    "setContentHandler(handler)\n"
    "Registers a new object to receive document content events."
    ;

static PyObject* PyXMLReader_setContentHandler(PyXMLReader* self, PyObject* args)
{
    return PyXMLReader_set_handler_slot(self->m_->cont_handler, args);
}


static char PyXMLReader_getDTDHandler_doc[] = 
    "getDTDHandler()\n"
    "Returns the current DTD handler."
    ;

static PyObject* PyXMLReader_getDTDHandler(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    return self->m_->dtd_handler.incref();
}


static char PyXMLReader_setDTDHandler_doc[] = 
    "setDTDHandler(handler)\n"
    "Register an object to receive basic DTD-related events."
    ;

static PyObject* PyXMLReader_setDTDHandler(PyXMLReader* self, PyObject* args)
{
    return PyXMLReader_set_handler_slot(self->m_->dtd_handler, args);
}


static char PyXMLReader_getEntityResolver_doc[] = 
    "getEntityResolver()\n"
    "Returns the current EntityResolver."
    ;

static PyObject* PyXMLReader_getEntityResolver(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    return self->m_->ent_handler.incref();
}


static char PyXMLReader_setEntityResolver_doc[] = 
    "setEntityResolver(resolver)\n"
    "Register an object to resolve external entities."
    ;

static PyObject* PyXMLReader_setEntityResolver(PyXMLReader* self, PyObject* args)
{
    return PyXMLReader_set_handler_slot(self->m_->ent_handler, args);
}


static char PyXMLReader_getErrorHandler_doc[] = 
    "getErrorHandler()\n"
    "Returns the current ErrorHandler."
    ;

static PyObject* PyXMLReader_getErrorHandler(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    return self->m_->err_handler.incref();
}


static char PyXMLReader_setErrorHandler_doc[] = 
    "setErrorHandler(handler)\n"
    "Register an object to receive error-message events."
    ;

static PyObject* PyXMLReader_setErrorHandler(PyXMLReader* self, PyObject* args)
{
    return PyXMLReader_set_handler_slot(self->m_->err_handler, args);
}


static char PyXMLReader_setLocale_doc[] = 
    "setLocale(locale)\n"
    "Allow an application to set the locale for errors and warnings."
    ;

static PyObject* PyXMLReader_setLocale(PyXMLReader* self, PyObject* args)
{
    return PirxxSetErrorObject(PirxxBuildSAXException(
        "SAXNotSupportedException", "Locale support not implemented"
    ));
}


static char PyXMLReader_getFeature_doc[] =
    "getFeature(name)\n"
    "Looks up and returns the state of a SAX2 feature."
    ;

static PyObject* PyXMLReader_getFeature(PyXMLReader* self, PyObject* args)
{
    PyObject* result = 0;

    // Check arguments
    PyObject* name = 0;
    if (!PyArg_ParseTuple(args, "O", &name)) return 0;

    try {
        PirxxObject uname(PyUnicode_FromObject(name), true);
        bool feature = self->parser->getFeature(PyUnicode_AS_UNICODE(uname.ptr()));
        result = PyInt_FromLong(feature);
    }
    catch (PythonExceptionCarrier& e) {
        e.restore();
    }
    catch (const SAXNotRecognizedException& e) {
        PirxxSetErrorObject(PirxxBuildSAXException("SAXNotRecognizedException", e.getMessage()));
    }
    catch (...) {
        PyErr_Format(PyExc_RuntimeError, "Unexpected C++ exception caught in " __FILE__ ":%d", __LINE__);
    }

    return result;
}


static char PyXMLReader_setFeature_doc[] = 
    "setFeature(name, state)\n"
    "Sets the state of a SAX2 feature.\n"
    "\n"
    "Supported features in SAX2 for xerces-c are:\n"
    "http://xml.org/sax/features/validation (default: true)\n"
    "http://xml.org/sax/features/namespaces (default: true)\n"
    "http://xml.org/sax/features/namespace-prefixes (default: false)\n"
    "http://apache.org/xml/features/validation/dynamic (default: false)\n"
    "http://apache.org/xml/features/validation/reuse-validator (default: false)\n"
    "http://apache.org/xml/features/validation/schema (1.5.1 and up, default: true)\n"
    "http://apache.org/xml/features/validation/reuse-grammar (1.5.2 and up, default: false)\n"
    "http://apache.org/xml/features/validation/schema-full-checking (1.5.2 and up, default: false)\n"
    ;

static PyObject* PyXMLReader_setFeature(PyXMLReader* self, PyObject* args)
{
    PyObject* result = 0;

    // Check arguments
    PyObject* name = 0;
    int feature = 0;
    if (!PyArg_ParseTuple(args, "Oi", &name, &feature)) return 0;

    try {
        PirxxObject uname(PyUnicode_FromObject(name), true);
        self->parser->setFeature(PyUnicode_AS_UNICODE(uname.ptr()), feature != 0);
        Py_INCREF(Py_None);
        return Py_None;
    }
    catch (PythonExceptionCarrier& e) {
        e.restore();
    }
    catch (const SAXNotRecognizedException& e) {
        PirxxSetErrorObject(PirxxBuildSAXException("SAXNotRecognizedException", e.getMessage()));
    }
    catch (const SAXNotSupportedException& e) {
        PirxxSetErrorObject(PirxxBuildSAXException("SAXNotSupportedException", e.getMessage()));
    }
    catch (...) {
        PyErr_Format(PyExc_RuntimeError, "Unexpected C++ exception caught in " __FILE__ ":%d", __LINE__);
    }

    Py_DECREF(name);
    return result;
}


static char property_lexical_handler[] = "http://xml.org/sax/properties/lexical-handler";

static char PyXMLReader_getProperty_doc[] = 
    "getProperty(name)\n"
    "Looks up and returns the value of a SAX2 property."
    ;

static PyObject* PyXMLReader_getProperty(PyXMLReader* self, PyObject* args)
{
    // Check arguments
    char* name = 0;
    if (!PyArg_ParseTuple(args, "s", &name)) return 0;

    if (strcmp(name, property_lexical_handler) == 0) {
        return self->m_->lex_handler.incref();
    }

    std::string msg = "Xerces does not support this SAX2 property: ";
    msg += name;
    return PirxxSetErrorObject(PirxxBuildSAXException(
        "SAXNotRecognizedException", msg.c_str()
    ));
}


static char PyXMLReader_setProperty_doc[] = 
    "setProperty(name, value)\n"
    "Sets the value of a SAX2 property."
    ;

static PyObject* PyXMLReader_setProperty(PyXMLReader* self, PyObject* args)
{
    // Check arguments
    char* name = 0;
    PyObject* property = 0;
    if (!PyArg_ParseTuple(args, "sO", &name, &property)) return 0;

    if (strcmp(name, property_lexical_handler) == 0) {
        self->m_->lex_handler = property;

        // Return None
        Py_INCREF(Py_None);
        return Py_None;
    }

    std::string msg = "Xerces does not support this SAX2 property: ";
    msg += name;
    return PirxxSetErrorObject(PirxxBuildSAXException(
        "SAXNotRecognizedException", msg.c_str()
    ));
}


/////////////////////////////////////////////////////////////////////////////
/// saxexts.ExtendedParser interface
/////////////////////////////////////////////////////////////////////////////

static char PyXMLReader_get_parser_name_doc[] =
    "get_parser_name() -> string\n"
    "Returns a single-word parser name.\n"
    ;

static char PyXMLReader_get_parser_version_doc[] =
    "get_parser_version() -> string\n"
    "Returns the version of the imported parser, which may not be the\n"
    "one the driver was implemented for.\n"
    ;

static char PyXMLReader_get_driver_version_doc[] =
    "get_driver_version() -> string\n"
    "Returns the version number of the driver.\n"
    ;

static char PyXMLReader_is_validating_doc[] =
    "is_validating() -> bool\n"
    "True if the parser is validating, false otherwise.\n"
    ;

static char PyXMLReader_is_dtd_reading_doc[] =
    "is_dtd_reading() -> bool\n"
    "True if the parser is non-validating, but conforms to the spec by reading the DTD.\n"
    ;


static PyObject* PyXMLReader_get_parser_name(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    return PyString_FromString("Xerces/C [PIRXX]");
}


static PyObject* PyXMLReader_get_parser_version(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;

    std::string version;
    for (unsigned long hex = PIRXX_XERCES_HEX_VERSION; hex; hex <<= 8) {
        if (version.length()) version += '.';
        version += '0' + (hex >> 24);
    }
    
    return PyString_FromString(version.c_str());
}


static PyObject* PyXMLReader_get_driver_version(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;

    std::string version;
    for (unsigned long hex = PIRXX_HEX_VERSION; hex; hex <<= 8) {
        if (version.length()) version += '.';
        version += '0' + (hex >> 24);
    }
    
    return PyString_FromString(version.c_str());
}


static PyObject* PyXMLReader_is_validating(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    return PyInt_FromLong(1L);
}


static PyObject* PyXMLReader_is_dtd_reading(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;
    return PyInt_FromLong(1L);
}


/////////////////////////////////////////////////////////////////////////////
/// Xerces IncrementalParser Interface
/////////////////////////////////////////////////////////////////////////////

static char PyXMLReader_feed_doc[] = 
    "feed(data)\n"
    "See xml.sax.xmlreader.IncrementalParser for details."
    ;

static char PyXMLReader_close_doc[] = 
    "close()\n"
    "See xml.sax.xmlreader.IncrementalParser for details."
    ;

static char PyXMLReader_reset_doc[] = 
    "reset()\n"
    "See xml.sax.xmlreader.IncrementalParser for details."
    ;


#if PIRXX_XERCES_HEX_VERSION <= 0x01050100

static PyObject* PyXMLReader_IncrementalParser_unsupported(PyXMLReader* self, PyObject* args)
{
    return PirxxSetErrorObject(PirxxBuildSAXException(
        "SAXNotSupportedException", "Xerces 1.5.1 and below does not support incremental parsing"
    ));
}

class PyIncrementalParser {
public:
    int dummy;
};

#define PyXMLReader_feed    PyXMLReader_IncrementalParser_unsupported
#define PyXMLReader_close   PyXMLReader_IncrementalParser_unsupported
#define PyXMLReader_reset   PyXMLReader_IncrementalParser_unsupported

#else

/*
    def feed(self, data):
        """This method gives the raw XML data in the data parameter to
        the parser and makes it parse the data, emitting the
        corresponding events. It is allowed for XML constructs to be
        split across several calls to feed.

        feed may raise SAXException."""
        raise NotImplementedError("This method must be implemented!")

    def close(self):
        """This method is called when the entire XML document has been
        passed to the parser through the feed method, to notify the
        parser that there are no more data. This allows the parser to
        do the final checks on the document and empty the internal
        data buffer.

        The parser will not be ready to parse another document until
        the reset method has been called.

        close may raise SAXException."""
        raise NotImplementedError("This method must be implemented!")

    def reset(self):
        """This method is called after close has been called to reset
        the parser so that it is ready to parse new documents. The
        results of calling parse or feed after close without calling
        reset are undefined."""
        raise NotImplementedError("This method must be implemented!")

virtual bool  parseFirst (const XMLCh *const systemId,XMLPScanToken &toFill,const bool reuseGrammar=false)=0 
  Begin a progressive parse operation. More...

 
virtual bool  parseFirst (const char *const systemId,XMLPScanToken &toFill,const bool reuseGrammar=false)=0 
  Begin a progressive parse operation. More...

 
  Begin a progressive parse operation. More...

 
  Continue a progressive parse operation. More...

 
virtual 
  Reset the parser after a progressive parse. More...
 

*/

class PyIncrementalParser : public parser_state {
public:
    PyIncrementalParser(PyXMLReader* self);
    ~PyIncrementalParser();

    void feed(const char* data);
    void close();
    void reset();

private:
    bool m_first_feed;
    XMLPScanToken m_token;
};


PyIncrementalParser::PyIncrementalParser(PyXMLReader* self)
    : parser_state(self)
    , m_first_feed(true)
{
}


PyIncrementalParser::~PyIncrementalParser()
{
}


void PyIncrementalParser::feed(const char* data)
{
    if (m_first_feed) {
        // bool parseFirst(const InputSource& source, m_token);
    } else {
        bool ok = parser.parseNext(m_token);
    }
}


void PyIncrementalParser::close()
{
    // !!! free input source
}


void PyIncrementalParser::reset()
{
    parser.parseReset(m_token);
}


static PyObject* PyXMLReader_feed(PyXMLReader* self, PyObject* args)
{
    if (!self->incparser) self->incparser = new PyIncrementalParser(self);

    // Check arguments
    char* data = 0;
    if (!PyArg_ParseTuple(args, "s", &data)) return 0;
 
    self->incparser->feed(data);

    // Return None
    Py_INCREF(Py_None);
    return Py_None;
}


static PyObject* PyXMLReader_close(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;

    if (self->incparser) {
        self->incparser->close();
    }

    // Return None
    Py_INCREF(Py_None);
    return Py_None;
}


static PyObject* PyXMLReader_reset(PyXMLReader* self, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;

    if (self->incparser) {
        self->incparser->reset();
        delete self->incparser;
        self->incparser = 0;
    }

    // Return None
    Py_INCREF(Py_None);
    return Py_None;
}

#endif


/////////////////////////////////////////////////////////////////////////////
/// Xerces XMLReader Object
/////////////////////////////////////////////////////////////////////////////

static char PyXMLReader_Type__doc__[] = 
    "Xerces Parser Object.\n"
    ;

PyTypeObject PyXMLReader_Type = {
    PyObject_HEAD_INIT(0)                // init at startup!
    0,                                   // ob_size
    "pirxx._pirxx.PyXMLReader",          // tp_name
    sizeof(PyXMLReader),                 // tp_basicsize
    0,                                   // tp_itemsize

    //  slots 
    (destructor) PyXMLReader_Free,       // tp_dealloc
    (printfunc) PyXMLReader_Print,       // tp_print
    (getattrfunc) PyXMLReader_GetAttr,   // tp_getattr
    (setattrfunc) PyXMLReader_SetAttr,   // tp_setattr
    (cmpfunc) 0,                         // tp_compare
    (reprfunc) 0,                        // tp_repr
    0,                                   // tp_as_number
    0,                                   // tp_as_sequence
    0,                                   // tp_as_mapping
    (hashfunc) 0,                        // tp_hash
    (ternaryfunc) 0,                     // tp_call
    (reprfunc) 0,                        // tp_str
    (getattrofunc) 0,                    // tp_getattro
    (setattrofunc) 0,                    // tp_setattro
    0,                                   // tp_as_buffer
    0,                                   // tp_xxx4
    PyXMLReader_Type__doc__              // tp_doc
};


statichere PyMethodDef PyXMLReader_Methods[] =
{
    PIRXX_METHOD_VA(PyXMLReader, parse),
    PIRXX_METHOD(PyXMLReader, getContentHandler),
    PIRXX_METHOD_VA(PyXMLReader, setContentHandler),
    PIRXX_METHOD(PyXMLReader, getDTDHandler),
    PIRXX_METHOD_VA(PyXMLReader, setDTDHandler),
    PIRXX_METHOD(PyXMLReader, getEntityResolver),
    PIRXX_METHOD_VA(PyXMLReader, setEntityResolver),
    PIRXX_METHOD(PyXMLReader, getErrorHandler),
    PIRXX_METHOD_VA(PyXMLReader, setErrorHandler),
    PIRXX_METHOD_VA(PyXMLReader, setLocale),
    PIRXX_METHOD_VA(PyXMLReader, getFeature),
    PIRXX_METHOD_VA(PyXMLReader, setFeature),
    PIRXX_METHOD_VA(PyXMLReader, getProperty),
    PIRXX_METHOD_VA(PyXMLReader, setProperty),

    // saxexts.ExtendedParser interface
    PIRXX_METHOD(PyXMLReader, get_parser_name),
    PIRXX_METHOD(PyXMLReader, get_parser_version),
    PIRXX_METHOD(PyXMLReader, get_driver_version),
    PIRXX_METHOD(PyXMLReader, is_validating),
    PIRXX_METHOD(PyXMLReader, is_dtd_reading),

    // IncrementalParser interface
    PIRXX_METHOD_VA(PyXMLReader, feed),
    PIRXX_METHOD(PyXMLReader, close),
    PIRXX_METHOD(PyXMLReader, reset),

    {0, 0} // end of list
};


PirxxObject PyXMLReader_New()
{
    PyXMLReader* self = PyObject_NEW(PyXMLReader, &PyXMLReader_Type);

    if (self) {
        // !!! TODO: Proper error handling (when objptrs == 0)!
        self->parser = XMLReaderFactory::createXMLReader();
        self->incparser = 0;

        // ??? Don't know what's more conforming, but I guess NOT setting "auto" by default is
        //self->parser->setFeature(SAX2XMLReaderImpl::SAX_XERCES_DYNAMIC, true);

        // set documented SAX2 default (note that the additional S in
        // SAX_CORE_NAMESPACES_PREFIXES is a Xerces typo that is NOT in the value itself)
        self->parser->setFeature(XMLUni::fgSAX2CoreNameSpacePrefixes, false);

        self->m_ = new PyXMLReader::cpp_members;
        self->m_->cont_handler = PirxxCallObject("xml.sax.handler", "ContentHandler");
        self->m_->dtd_handler = PirxxCallObject("xml.sax.handler", "DTDHandler");
        self->m_->ent_handler = PirxxCallObject("xml.sax.handler", "EntityResolver");
        self->m_->err_handler = PirxxCallObject("xml.sax.handler", "ErrorHandler");

        Py_INCREF(Py_None);
        self->m_->lex_handler = Py_None;
    }

    return PirxxObject((PyObject*) self, true);
}


static void PyXMLReader_Free(PyXMLReader* self)
{
    delete self->incparser; self->incparser = 0;
    delete self->parser; self->parser = 0;
    delete self->m_; self->m_ = 0;

    PyMem_DEL(self);
}


void PyXMLReader_Init()
{
    // Patch type objects
    PyXMLReader_Type.ob_type = &PyType_Type;
}

