/* PyInputSource.cpp - Bridge between Xerces and Python input sources
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: PyInputSource.cpp,v 1.6 2003/02/28 10:18:09 jhermann Exp $
 */

#include "PyInputSource.h"

// Python
#include <Python.h>

// Xerces
#include <xercesc/util/BinInputStream.hpp>

// PIRXX
#include "PirxxUtil.h"


/////////////////////////////////////////////////////////////////////////////
/// PyInputStream (local helper class)
/////////////////////////////////////////////////////////////////////////////

class PyInputStream : public BinInputStream {
public:
    PyInputStream(PyObject* stream);
    virtual ~PyInputStream();

    virtual unsigned int curPos() const;
    virtual unsigned int readBytes(XMLByte* const toFill, const unsigned int maxToRead);

private:
    PyObject* m_stream;
};


PyInputStream::PyInputStream(PyObject* stream)
    : m_stream(stream)
{
    // ctor takes ownership!!!
    // Py_INCREF(m_stream);
}


PyInputStream::~PyInputStream()
{
    Py_DECREF(m_stream);
}


unsigned int PyInputStream::curPos() const
{
    PyObject* pos = PyObject_CallMethod(m_stream, "tell", 0);
    if (!pos) throw PythonExceptionCarrier();
    long lpos = PyInt_AsLong(pos);
    if (PyErr_Occurred()) throw PythonExceptionCarrier();

    return (unsigned int) lpos;
}


unsigned int PyInputStream::readBytes(XMLByte* const toFill, const unsigned int maxToRead)
{
    PyObject* buff = PyObject_CallMethod(m_stream, "read", "(i)", maxToRead);
    if (!buff) throw PythonExceptionCarrier();
    if (!PyString_Check(buff)) {
        PyErr_Format(PyExc_TypeError,
            "read() did not return a string object (type=%.400s)",
            buff->ob_type->tp_name);
        Py_DECREF(buff);
        throw PythonExceptionCarrier();
    }

    unsigned int len = PyString_GET_SIZE(buff);
    if (len) memcpy(toFill, PyString_AS_STRING(buff), len);
    Py_DECREF(buff);

    //PIRXX_DEBUG("PyInputStream::readBytes - read " << len << " bytes");

    return len;
}


/////////////////////////////////////////////////////////////////////////////
/// PyInputSource
/////////////////////////////////////////////////////////////////////////////

PyInputSource::PyInputSource(PyObject* source)
    : m_source(source)
{
    Py_INCREF(m_source);

    // Transfer attributes into C++ object
    copy_attr("getPublicId", &InputSource::setPublicId);
    copy_attr("getSystemId", &InputSource::setSystemId);
    copy_attr("getEncoding", &InputSource::setEncoding);

    if (PyErr_Occurred()) throw PythonExceptionCarrier();

    //PIRXX_DEBUG("created input source for '" << PirxxTranscode(getSystemId()) << "'");
}


PyInputSource::~PyInputSource()
{
    Py_DECREF(m_source);
}


void PyInputSource::copy_attr(const char* name, void (InputSource::*modifier)(const XMLCh*const))
{
    if (PyErr_Occurred()) return;

    PyObject* attr = PyObject_CallMethod(m_source, const_cast<char*>(name), 0);
    if (attr) {
        if (attr != Py_None) {
            PyObject* uniattr = PyUnicode_FromObject(attr); 
            if (uniattr) { 
                (this->*modifier)(PyUnicode_AS_UNICODE(uniattr));
                Py_DECREF(uniattr);
            }
        }
        Py_DECREF(attr);
    }
}


BinInputStream* PyInputSource::makeStream() const
{
    // We do NOT support CharacterStreams at this time!
    PyObject* stream = PyObject_CallMethod(m_source, "getByteStream", 0);
    if (!stream) throw PythonExceptionCarrier();

    return new PyInputStream(stream);
}
