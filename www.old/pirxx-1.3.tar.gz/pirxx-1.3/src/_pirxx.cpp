/* _pirxx.cpp - Extension module for wrapping Xerces/Xalan
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: _pirxx.cpp,v 1.17 2001/11/13 21:38:17 jhermann Exp $
 */

// C Runtime

// Python
#include <Python.h>

// PIRXX
#include "PirxxLocator.h"
#include "PirxxUtil.h"
#include "PyXMLReader.h"


/////////////////////////////////////////////////////////////////////////////
/// Module functions
/////////////////////////////////////////////////////////////////////////////

static char mod_pirxx_create_parser_doc[] =
    "create_parser()\n"
    "\n"
    "Returns a Xerces parser object.\n"
    ;

static PyObject* mod_pirxx_create_parser(PyObject*, PyObject* args)
{
    if (!PyArg_NoArgs(args)) return 0;

    return PyXMLReader_New().incref();
}


/////////////////////////////////////////////////////////////////////////////
/// Module Init
/////////////////////////////////////////////////////////////////////////////

static PyMethodDef mod_pirxx_methods[] = {
    // Parser Interface
    PIRXX_METHOD(mod_pirxx, create_parser),

    {0, 0} // end of list
};

static char mod_pirxx_doc[] = "Python InteRface to Xerces and Xalan";

extern "C" DL_EXPORT(void) init_pirxx()
{
    // Call init functions of extension types
    PirxxLocator_Init();
    PyXMLReader_Init();

    if (PirxxXMLInitialize()) {
        PyObject* mod_pirxx = Py_InitModule4("_pirxx", mod_pirxx_methods, mod_pirxx_doc, 
            (PyObject*) 0, PYTHON_API_VERSION);

        PyObject* pirxx_dict = PyModule_GetDict(mod_pirxx);
        std::string version = gXercesFullVersionStr;
        for (int i = 0; i < version.length(); ++i) {
            if (version[i] == '_') version[i] = '.';
        }
        PirxxObject pyversion = PyString_FromString(version.c_str());
        PyDict_SetItemString(pirxx_dict, "xerces_version", pyversion);
    }
}

