/* PirxxUtil.cpp - Utility functions and classes
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: PirxxUtil.cpp,v 1.17 2003/02/28 10:18:09 jhermann Exp $
 */

#include "PirxxUtil.h"

// C Runtime
#include <locale.h>

// Python
#include <Python.h>

// Xerces
#include <xercesc/sax/SAXParseException.hpp>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/util/XMLString.hpp>

// PIRXX
#include "PirxxLocator.h"


//////////////////////////////////////////////////////////////////////////////
// PythonExceptionCarrier
//////////////////////////////////////////////////////////////////////////////

PythonExceptionCarrier::PythonExceptionCarrier() throw()
{
    PyErr_Fetch(&m_type, &m_value, &m_traceback);
}


PythonExceptionCarrier::PythonExceptionCarrier(const PythonExceptionCarrier& ex) throw()
    : m_type(ex.m_type)
    , m_value(ex.m_value)
    , m_traceback(ex.m_traceback)
{
    Py_XINCREF(m_type);
    Py_XINCREF(m_value);
    Py_XINCREF(m_traceback);
}


PythonExceptionCarrier::~PythonExceptionCarrier() throw()
{
    // In case the exception got not restored, give up our references
    Py_XDECREF(m_type);
    Py_XDECREF(m_value);
    Py_XDECREF(m_traceback);
}


PyObject* PythonExceptionCarrier::restore()
{
    if (!m_type) {
        PyErr_SetString(PyExc_RuntimeError, 
            "PythonExceptionCarrier: There's no Python exception to restore!");
    } else {
        // Restore the Python exception, ownership is transferred to the Python interpreter;
        // thus we void our object pointers.
        PyErr_Restore(m_type, m_value, m_traceback);
        m_type = m_value = m_traceback = 0;
    }

    return 0;
}


//////////////////////////////////////////////////////////////////////////////
// PirxxObject
//////////////////////////////////////////////////////////////////////////////

PirxxObject& PirxxObject::operator=(PyObject* obj)
{
    if (obj != m_obj) {
        Py_XDECREF(m_obj);
        m_obj = obj;
        Py_XINCREF(m_obj);
    }

    return *this;
}


//////////////////////////////////////////////////////////////////////////////
// Object creation functions
//////////////////////////////////////////////////////////////////////////////

PirxxObject PirxxGetObject(const char* modulename, const char* key)
{
    // Import module
    PirxxObject pymod(PyImport_ImportModule(const_cast<char*>(modulename)), true);
    
    // Get namespace dict and from that the desired value (a BORROWED ref)
    PyObject* pydict = PyModule_GetDict(pymod);
    PyObject* obj = PyDict_GetItemString(pydict, const_cast<char*>(key));
    if (!obj) {
        PyErr_SetString(PyExc_AttributeError, const_cast<char*>(key));
        throw PythonExceptionCarrier();
    }

    return obj;
}


// takes ownership of args!!!
PirxxObject PirxxCallObject(const char* modulename, const char* callee, PyObject* args)
{
    PirxxObject auto_args(args ? args : Py_BuildValue("()"), true);
    PirxxObject funcobj = PirxxGetObject(modulename, callee);

    PyObject* result = PyEval_CallObject(funcobj, args);
    if (!result) return 0;

    return PirxxObject(result, true);
}


PirxxObject PirxxBuildUnicode(const XMLCh* xmlstr)
{
    return PirxxObject(PyUnicode_FromUnicode(xmlstr, XMLString::stringLen(xmlstr)), true);
}


PirxxObject PirxxBuildStringOrUnicode(const XMLCh* xmlstr)
{
    PirxxObject result = PirxxBuildUnicode(xmlstr);
    if (result) {
        PyObject* usascii = PyUnicode_AsASCIIString(result);
        if (usascii) {
            result = usascii;
            Py_DECREF(usascii);
        } else {
            PyErr_Clear();
        }
    }

    return result;
}


PirxxObject PirxxBuildNoneOrStringOrUnicode(const XMLCh* xmlstr)
{
    if (!xmlstr || !*xmlstr) {
        return Py_None;
    }
    return PirxxBuildStringOrUnicode(xmlstr);
}


/////////////////////////////////////////////////////////////////////////////
/// Exceptions
/////////////////////////////////////////////////////////////////////////////

PirxxObject PirxxBuildSAXException(const char* excname, const char* msg)
{
    PirxxObject pymsg(PyString_FromString(msg ? msg : ""), true);
    return PirxxBuildSAXException(excname, pymsg);
}


PirxxObject PirxxBuildSAXException(const char* excname, const XMLCh* msg)
{
    XMLCh null = 0;
    PirxxObject umsg = PirxxBuildUnicode(msg ? msg : &null);
    return PirxxBuildSAXException(excname, umsg);
}


PirxxObject PirxxBuildSAXException(const char* excname, PirxxObject& msg)
{
    if (!msg) return 0;

    PyObject* args = Py_BuildValue("(OO)", msg.ptr(), Py_None);
    if (!args) {
        return 0;
    }

    return PirxxCallObject("xml.sax._exceptions", excname ? excname : "SAXException", args);
}


PirxxObject PirxxBuildSAXParseException(const SAXParseException& exception)
{
    PirxxObject msg = PirxxBuildUnicode(exception.getMessage());
    PirxxObject loc = PirxxExcLocator_New(
        exception.getPublicId(), exception.getSystemId(),
        exception.getLineNumber(), exception.getColumnNumber());
    PirxxObject args(Py_BuildValue("(OOO)", msg.ptr(), Py_None, loc.ptr()), true);

    return PirxxCallObject("xml.sax._exceptions", "SAXParseException", args.incref());
}


PyObject* PirxxSetErrorObject(PirxxObject exc)
{
    PirxxObject exc_type(PyObject_GetAttrString(exc, "__class__"), true);
    PyErr_SetObject(exc_type, exc);

    return 0;
}


/////////////////////////////////////////////////////////////////////////////
/// Transcoding
/////////////////////////////////////////////////////////////////////////////

std::string PirxxTranscode(const XMLCh* xercesstring)
{
    char* buffer = XMLString::transcode(xercesstring);
    std::string result(buffer);
    delete[] buffer;

    return result;
}


/////////////////////////////////////////////////////////////////////////////
/// Initialization
/////////////////////////////////////////////////////////////////////////////

int PirxxXMLInitialize()
{
    // Initialize never more than once
    static bool bIsInitialized = false;
    int ok = 1;
    
    if (!bIsInitialized) {
        // Order is important here!

        // Initialize "locale"
        char* currentLocale = setlocale(LC_ALL, 0);
        if (!currentLocale || strcmp(currentLocale, "C") == 0) {
            currentLocale = setlocale(LC_ALL, "");
            if (currentLocale == 0) {
                // Don't count it as an error
            }
        }

        // Initialize Xerces
        try {
            XMLPlatformUtils::Initialize();
        }
        catch (const XMLException& toCatch) {
            PyErr_Format(PyExc_ImportError, 
                "Error during Xerces initialization: %s", 
                PirxxTranscode(toCatch.getMessage()).c_str());
            ok = 0;
        }

        bIsInitialized = true;
    }

    return ok;
}
