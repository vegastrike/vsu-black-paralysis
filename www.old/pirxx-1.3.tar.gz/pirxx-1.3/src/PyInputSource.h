/* PyInputSource.h - Bridge between Xerces and Python input sources
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: PyInputSource.h,v 1.5 2003/02/28 10:18:09 jhermann Exp $
 */

#ifndef PIRXX_PYINPUTSOURCE_H
#define PIRXX_PYINPUTSOURCE_H

// Python
#include <Python.h>

// Xerces
#include <xercesc/sax/InputSource.hpp>


class PyInputSource : public InputSource {
public:
    /// ctor takes ownership!!!
    PyInputSource(PyObject* source);
    virtual ~PyInputSource();

    virtual BinInputStream* makeStream() const;

private:
    // overload unwanted compiler defaults
    PyInputSource(const PyInputSource&);
    PyInputSource& operator=(const PyInputSource&);

    void copy_attr(const char* name, void (InputSource::*modifier)(const XMLCh*const));

    PyObject* m_source;
};


#endif
