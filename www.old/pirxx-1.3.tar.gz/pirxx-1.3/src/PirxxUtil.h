/* PirxxUtil.h - Utility functions and classes
 *
 * Copyright (c) 2001 by WEB.DE AG
 * 
 * $Id: PirxxUtil.h,v 1.17 2003/02/28 10:18:09 jhermann Exp $
 */

#ifndef PIRXX_PIRXXUTIL_H
#define PIRXX_PIRXXUTIL_H

// C Runtime
#include <exception>
#include <string>
#include <iostream>

// Python
#include <Python.h>

// Xerces
#include <xercesc/util/PlatformUtils.hpp>

// forwards
class SAXParseException;


/** Base class for exceptions.
*/
class PirxxException : public std::exception {
public:
    /// ctors
    PirxxException() {}
    PirxxException(const std::string& msg) : m_msg(msg) {}

    /// dtor
    virtual ~PirxxException() {}

    // compiler defaults for copy ctor and assignment are OK.

    /// Return exception message.
    virtual const char* what() const throw() { return m_msg.c_str(); }

protected:
    std::string m_msg;
};


/** Tunnel Python exceptions through C++ code.
*/
class PythonExceptionCarrier {
public:
    /** Store (and remove) a Python exception, if one is set.
    */
    PythonExceptionCarrier() throw();
    PythonExceptionCarrier(const PythonExceptionCarrier& ex) throw();
    ~PythonExceptionCarrier() throw();

    /** Restore the exception.
        
        @return Always 0 (so that you can write "return ex.restore();")
    */
    PyObject* restore();

private:
    // overload unwanted compiler defaults
    PythonExceptionCarrier& operator=(const PythonExceptionCarrier&);

    PyObject* m_type;
    PyObject* m_value;
    PyObject* m_traceback;
};


/** Smart PyObject pointer with automatic reference management.
*/
class PirxxObject {
public:
    /// ctors
    PirxxObject() : m_obj(0) {}
    PirxxObject(PyObject* obj, bool take_ownership = false) : m_obj(obj) {
        if (!m_obj && PyErr_Occurred()) throw PythonExceptionCarrier();
        if (!take_ownership) Py_XINCREF(m_obj);
    }
    PirxxObject(const PirxxObject& obj) : m_obj(obj.m_obj) { Py_XINCREF(m_obj); }

    /// dtor
    ~PirxxObject() { Py_XDECREF(m_obj); m_obj = 0; }

    PyObject* incref() { Py_XINCREF(m_obj); return m_obj; }
    void decref() { Py_XDECREF(m_obj); }

    PirxxObject& operator=(const PirxxObject& obj) { return operator=(obj.m_obj); }
    PirxxObject& operator=(PyObject* obj);

    PyObject* ptr() { return m_obj; }
    PyObject* operator ->() { return m_obj; }
    operator PyObject*() { return m_obj; }

protected:
    PyObject* m_obj;
};


/** Fetch an object \a key from the module \a modulename.

    \param modulename Name of the module.
    \param key Name of the object.
    \return \b Borrowed reference to the object, 
        or 0 in case it does not exist.
    \exception PythonExceptionCarrier If module is not importable or object cannot be found.
*/
extern PirxxObject PirxxGetObject(const char* modulename, const char* key);

extern PirxxObject PirxxCallObject(const char* modulename, const char* callee, PyObject* args = 0);

extern PirxxObject PirxxBuildUnicode(const XMLCh* xmlstr);
extern PirxxObject PirxxBuildStringOrUnicode(const XMLCh* xmlstr);
extern PirxxObject PirxxBuildNoneOrStringOrUnicode(const XMLCh* xmlstr);

extern PirxxObject PirxxBuildSAXException(const char* excname, const char* msg);
extern PirxxObject PirxxBuildSAXException(const char* excname, const XMLCh* msg);
extern PirxxObject PirxxBuildSAXException(const char* excname, PirxxObject& msg);
extern PirxxObject PirxxBuildSAXParseException(const SAXParseException& exception);
extern PyObject* PirxxSetErrorObject(PirxxObject exc);

/** Transcode to a C++ string, eases memory management at the expense of some copying.
*/
extern std::string PirxxTranscode(const XMLCh* xercesstring);

extern int PirxxXMLInitialize();


// Switchable debugging
#define DEBUG 1
#if DEBUG
#define PIRXX_DEBUG(output) (std::cerr << output << std::endl)
#else
#define PIRXX_DEBUG(output)
#endif

// Extension type helpers
#define PIRXX_METHOD(prefix, funcname) \
    {#funcname, (PyCFunction) prefix##_##funcname, 0, prefix##_##funcname##_doc}

#define PIRXX_METHOD_VA(prefix, funcname) \
    {#funcname, (PyCFunction) prefix##_##funcname, METH_VARARGS, prefix##_##funcname##_doc}

#define PIRXX_METHOD_KW(prefix, funcname) \
    {#funcname, (PyCFunction) prefix##_##funcname, METH_VARARGS|METH_KEYWORDS, prefix##_##funcname##_doc}


#endif
