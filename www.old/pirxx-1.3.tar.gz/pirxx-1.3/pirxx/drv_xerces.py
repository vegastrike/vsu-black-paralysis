"""
SAX2 driver for Xerces

Copyright (c) 2001 by WEB.DE AG

$Id: drv_xerces.py,v 1.7 2001/08/30 11:01:02 jhermann Exp $

"""
__author__  = "J�rgen Hermann (WEB.DE AG)"
__version__ = "$Revision: 1.7 $"[11:-2]

from pirxx._pirxx import create_parser
