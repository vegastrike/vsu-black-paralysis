"""
Package Initialization of Package "pirxx"

To create a Xerces parser instance, use
`parser = xml.sax.sax2exts.make_parser('pirxx')`
or set the "PY_SAX_PARSER" environment variable to "pirxx".

Copyright (c) 2001 by WEB.DE AG

$Id: __init__.py,v 1.5 2001/11/13 21:38:17 jhermann Exp $

"""
__author__ = "J�rgen Hermann (WEB.DE AG)"

from pirxx.version import revision
__version__ = revision
version_info = tuple(map(int, __version__.split('.')))
del revision

# allow pirxx to be imported w/o the extension module (needed for setup.py)
try:
    from pirxx._pirxx import create_parser, xerces_version
except ImportError, e:
    def create_parser(ex=e):
        raise ex
    xerces_version = "<unknown>"

# SAX2 features (Xerces 1.4.0 and up)
feature_validation_dynamic = "http://apache.org/xml/features/validation/dynamic"
feature_validation_reuse = "http://apache.org/xml/features/validation/reuse-validator"

# Introduced with Xerces 1.5.1
feature_validation_schema = "http://apache.org/xml/features/validation/schema"

# Introduced with Xerces 1.5.2
feature_validation_reuse_grammar = "http://apache.org/xml/features/validation/reuse-grammar"
feature_validation_schema_full_checking = "http://apache.org/xml/features/validation/schema-full-checking"

