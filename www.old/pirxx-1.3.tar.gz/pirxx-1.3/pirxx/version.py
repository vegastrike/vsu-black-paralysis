"""
Version of Package "pirxx"

This file serves no other purpose than holding the official revision 
number of the whole package; thus, its CVS version and the package 
version are identical.

Copyright (c) 2001 by WEB.DE AG

$Id: version.py,v 1.3 2001/10/25 21:45:28 jhermann Exp $

"""
revision = '$Revision: 1.3 $'[11:-2]

if __name__ == "__main__":
    # Bump own revision
    import os
    os.system('cvs ci -f -m "Bumped revision" version.py')
