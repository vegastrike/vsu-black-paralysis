import os, sys
from xml.sax import sax2exts, saxutils, handler, SAXNotSupportedException, SAXNotRecognizedException

class Handler(saxutils.DefaultHandler):

    def __init__(self):
        parser = sax2exts.make_parser('pirxx')
        #parser = sax2exts.make_parser(['xml.sax.drivers2.drv_xmlproc'])
        print parser
    
        parser.setFeature(handler.feature_namespaces, 1)
        parser.setFeature(handler.feature_validation, 1)
    
        parser.setContentHandler(self)
        parser.setErrorHandler(self)
        #parser.setErrorHandler(None)
        
        parser.parse('UIInstance.xml')


h = Handler()