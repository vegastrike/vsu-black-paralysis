"""
Tests for PIRXX

Copyright (c) 2001 by WEB.DE AG

This is a messy little test script.

$Id: test_pirxx.py,v 1.8 2001/11/19 22:23:56 jhermann Exp $

"""
__author__  = "J�rgen Hermann (WEB.DE AG)"
__version__ = "$Revision: 1.8 $"[11:-2]

import os, sys

xmltestfile = "books.xml"
#xmltestfile = "hamlet.xml"

# Test parsing
from xml.sax import sax2exts, saxutils, handler, SAXNotSupportedException, SAXNotRecognizedException


def dumprefs(filename):
    objs = sys.getobjects(50000)
    file = open(filename, 'w')
    for o in objs:
        print >>file, repr(o)
    file.close()
    del file, objs, o


class TestGenerator(saxutils.XMLGenerator):
    def __init__(self):
        saxutils.XMLGenerator.__init__(self)

    def startElement(self, name, attrs):
        saxutils.XMLGenerator.startElement(self, name, attrs)
        self._out.write('***%s:%d:%d***' % (
            self._locator.getSystemId(),
            self._locator.getLineNumber(),
            self._locator.getColumnNumber()))

    def startElementNS(self, name, qname, attrs):
        saxutils.XMLGenerator.startElementNS(self, name, qname, attrs)
        self._out.write('***%s:%d:%d***' % (
            self._locator.getSystemId(),
            self._locator.getLineNumber(),
            self._locator.getColumnNumber()))

    def skippedEntity(self, name):
        print ">>> skipped entity:", name

    # -- LexicalHandler interface

    def comment(self, content):
        print ">>> comment:", content

    def startDTD(self, name, public_id, system_id):
        print ">>> Start of DTD:", name, public_id, system_id

    def endDTD(self):
        print ">>> End of DTD"

    def startEntity(self, name):
        print ">>> start of entity:", name

    def endEntity(self, name):
        print ">>> end of entity:", name

    def startCDATA(self):
        print ">>> start of CDATA"

    def endCDATA(self):
        print ">>> end of CDATA"


def test():
    #parser = sax2exts.make_parser()
    parser = sax2exts.make_parser('pirxx')
    #parser = sax2exts.make_parser(['xml.sax.drivers2.drv_xmlproc'])
    print parser

    print "get_parser_name =", parser.get_parser_name()
    print "get_parser_version =", parser.get_parser_version()
    print "get_driver_version =", parser.get_driver_version()
    print "is_validating =", parser.is_validating()
    print "is_dtd_reading =", parser.is_dtd_reading()

    print "n =", parser.getFeature(handler.feature_namespaces)
    try:
        print "v =", parser.getFeature(handler.feature_validation)
    except (SAXNotRecognizedException, SAXNotSupportedException):
        pass

    parser.setFeature(handler.feature_namespaces, 1)
    try:
        parser.setFeature(handler.feature_validation, 1)
    except (SAXNotRecognizedException, SAXNotSupportedException):
        pass
    #parser.setFeature(handler.feature_external_ges, 1)
    #parser.setFeature(handler.feature_external_pes, 1)
    print "n =", parser.getFeature(handler.feature_namespaces)
    try:
        print "v =", parser.getFeature(handler.feature_validation)
    except (SAXNotRecognizedException, SAXNotSupportedException):
        pass

    ch = TestGenerator() #saxutils.XMLGenerator()
    parser.setContentHandler(ch)
    parser.setErrorHandler(handler.ErrorHandler())
    #parser.setErrorHandler(None)
    parser.setProperty(handler.property_lexical_handler, ch)
    parser.parse(os.path.join(os.path.dirname(sys.argv[0]), xmltestfile))
    print

    try:
        print ch._locator.getSystemId()
    except SAXNotSupportedException, e:
        assert e.getMessage() == "Locator access after parse"
        del e
    else:
        assert 0, "Expected SAXNotSupportedException"

    print "OK!"
    
    del parser
    del ch


# reference / alloc debugging
has_trace_refs = 0 and hasattr(sys, 'gettotalrefcount')
has_count_allocs = 0 and hasattr(sys, 'getcounts')
if has_count_allocs:
    start_counts = {}
    for count in sys.getcounts():
        typename, allocs, frees, maxalloc = count
        start_counts[typename] = allocs - frees
    for count in sys.getcounts():
        typename, allocs, frees, maxalloc = count
        start_counts[typename] = allocs - frees
if has_trace_refs:
    # create variables before counting references
    start_refcount = 0
    end_refcount = 0
    start_refcount = sys.gettotalrefcount()

if len(sys.argv) < 2:
    test()
elif sys.argv[1] == "notest":
    pass
elif sys.argv[1] == "reftest":
    current = sys.gettotalrefcount()
    lastcount = current
    sys.stdout = open("/dev/null", "w")
    for i in range(10):
        test()
        current = sys.gettotalrefcount()
        print >>sys.__stdout__, current, current - lastcount
        lastcount = current
        #if i in [1,2]: dumprefs("refs%d" % i)

if has_count_allocs:
    counts = sys.getcounts()
    counts.sort()
    for count in counts:
        typename, allocs, frees, maxalloc = count
        if allocs != frees and (allocs - frees) != start_counts[typename]:
            print "!!! %s: %d unfreed objects" % (typename, allocs - frees,)
if has_trace_refs:
    end_refcount = sys.gettotalrefcount()
    print "start = %d; end = %d; diff = %d" % (
        start_refcount, end_refcount, end_refcount - start_refcount)
