#! /usr/bin/env python
"""
Package installer for "pirxx"

Copyright (c) 2001 by WEB.DE AG

$Id: setup.py,v 1.13 2003/02/28 10:18:08 jhermann Exp $

"""
__author__  = "J�rgen Hermann (WEB.DE AG)"
__version__ = "$Revision: 1.13 $"[11:-2]

import glob, os, sys
from distutils.core import setup, Extension
from pirxx.version import revision

#############################################################################
### Helpers
#############################################################################

def hexversion(version):
    return ('0x' + ''.join(["%02X" % int(num) for num in version.split('.')]) + '0000')[:10]


#############################################################################
### Call setup()
#############################################################################

# get Xerces base directory
xerces_root = os.environ.get('XERCESCROOT')
if not xerces_root:
    print >>sys.stderr, "You MUST set the XERCESCROOT environment variable!"
    sys.exit(1)

# get Xerces version
versionfile = open(os.path.join(xerces_root, 'version.incl'), 'r')
xerces_version = [v.strip() for v in versionfile.readlines() if v.startswith('VER=')]
xerces_version = xerces_version[0][4:]

# set up paths & libraries
xerces_include_dir = os.path.join(xerces_root, 'src')
if not os.path.exists(xerces_include_dir):
    xerces_include_dir = os.path.join(xerces_root, 'include')

xerces_library_dir = os.path.join(xerces_root, 'lib')
xerces_library = 'xerces-c'
if sys.platform.startswith('win32'):
    # should support "--debug / -g" flag of "build" action
    libdirs = [
        os.path.join(xerces_root, 'Build', 'Win32', 'VC6', 'Release'),
        os.path.join(xerces_root, 'lib'),
    ]
    xerces_library_dir = None
    for dir in libdirs:
        if os.path.isdir(dir):
            xerces_library_dir = dir
            break
    if not xerces_library_dir:
        print >>sys.stderr, "Cannot locate library directory, tried:\n    " + '\n    '.join(libdirs)
        sys.exit(1)
    xerces_library = 'xerces-c_' + xerces_version
    if not os.path.exists(os.path.join(xerces_library_dir, xerces_library + '.lib')):
        xerces_library = 'xerces-c_' + xerces_version.split('_')[0]

print >>sys.stderr, "*** PIRXX for Xerces v%s" % xerces_version.replace('_', '.')

# distutils setup information
setup_args = {
    'name': "pirxx",
    'version': revision,
    'description': "Python InteRface to Xerces and Xalan",
    'long_description': "PIRXX provides a Python InteRface to Xerces and Xalan, integrating it into PyXML.",
    'licence': 'Python License',
    'author': "WEB.DE AG",
    'author_email': "jhe@webde-ag.de",
    'maintainer': "J�rgen Hermann",
    'maintainer_email': "jhe@webde-ag.de",
    'url': "http://pirxx.sourceforge.net/",
    'packages': [
        'pirxx',
    ],
    'ext_modules': [
        Extension("pirxx._pirxx", 
            glob.glob("src/*.cpp"),
            include_dirs=[
                xerces_include_dir,
            ],
            library_dirs=[
                xerces_library_dir,
            ],
            libraries=[
                xerces_library,
            ],
            define_macros=[
                ('PIRXX_HEX_VERSION', hexversion(revision)),
                ('PIRXX_XERCES_HEX_VERSION', hexversion(xerces_version.replace('_', '.'))),
            ],
            #extra_objects=extra_objects
        )
    ],
}

# call distutils
setup(**setup_args)

